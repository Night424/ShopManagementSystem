#Import class to main file 
from ctuClass import *

#Create shops with details
shop1 = ctuStock('default','default', 0, 0 ,0)
shop2 = ctuStock('default','default', 0, 0 ,0)
shop3 = ctuStock('default','default', 0, 0 ,0)
shop4 = ctuStock('default','default', 0, 0 ,0)

#Init stock
comp_stock = 100
cable_stock = 100
component_stock = 100
screen_stock = 100

#Create dictionary for stock
stock = {'1. Computers' : {'Price':'R1000','In Stock': comp_stock},'2. Cables' : {'Price':'R100','In Stock': cable_stock},'3. Components' : {'Price':'R50','In Stock': component_stock},'4. Screens' : {'Price':'R1000','In Stock': screen_stock}}

#Use a while loop for the whole code
while True:
    #Create main menu function
    def mainMenu():
        print("Welcome to CTU Technologies\n")

        print("1. Shop Management")
        print("2. Sales")
        print("3. Returns")
        print("4. Stock")
        print("99. Exit\n")

    #Create management menu function
    def managementMenu():
        print("Shop Management")
        print("1. Change shop Name")
        print("2. Change shop location")
        print("3. Display current shops")
        print("4. Display all shops information")
        print("0. Back\n")

    #Create change name function
    def chngName():
        print("Change Shop name\n")

        print("Select Shop ")
        print("1. ", shop1.shopName,",", shop1.shopLocation)
        print("2. ", shop2.shopName,",", shop2.shopLocation)
        print("3. ", shop3.shopName,",", shop3.shopLocation)
        print("4. ", shop4.shopName,",", shop4.shopLocation)
        print("0. back")

    #Create current shop function
    def crrtShops():
        print("Current shops")
        print("1. ", shop1.shopName,",", shop1.shopLocation)
        print("2. ", shop2.shopName,",", shop2.shopLocation)
        print("3. ", shop3.shopName,",", shop3.shopLocation)
        print("4. ", shop4.shopName,",", shop4.shopLocation)

    #Create all shop details function
    def allShopDetails():
            print("--------------\n") 
            print("Shop Name: ", shop1.shopName)    
            print("Shop location: ", shop1.shopLocation)
            print("Number of Customers: ",shop1.customers)
            print("Current Sales: ", shop1.sales)
            print("Returns: ", shop1.returns)
            print("\n--------------") 

            print("--------------\n") 
            print("Shop Name: ", shop2.shopName)    
            print("Shop location: ", shop2.shopLocation)
            print("Number of Customers: ",shop2.customers)
            print("Current Sales: ", shop2.sales)
            print("Returns: ", shop2.returns)
            print("\n--------------") 

            print("--------------\n") 
            print("Shop Name: ", shop3.shopName)    
            print("Shop location: ", shop3.shopLocation)
            print("Number of Customers: ",shop3.customers)
            print("Current Sales: ", shop3.sales)
            print("Returns: ", shop3.returns)
            print("\n--------------") 

            print("--------------\n") 
            print("Shop Name: ", shop4.shopName)    
            print("Shop location: ", shop4.shopLocation)
            print("Number of Customers: ",shop4.customers)
            print("Current Sales: ", shop4.sales)
            print("Returns: ", shop4.returns)
            print("\n--------------") 

    #Create management name changed function
    def manageNameChng():
            if optN == "1":
                shop1.shopName = newName
                print("\nShop name was successfully changed to "+ newName)

            if optN == "2":
                shop2.shopName = newName
                print("\nShop name was successfully changed to "+ newName)

            if optN == "3":
                shop3.shopName = newName
                print("\nShop name was successfully changed to "+ newName)

            if optN == "4":
                shop4.shopName = newName
                print("\nShop name was successfully changed to "+ newName)

            if optN == "0":
                chngName()

    #Create manangement location change function
    def manageLocChng():
            if optL == "1":
                shop1.shopLocation = newLoc
                print("\nShop location was successfully changed to "+ newLoc)

            if optL == "2":
                        shop2.shopLocation = newLoc
                        print("\nShop location was successfully changed to "+ newLoc)

            if optL == "3":
                        shop3.shopLocation = newLoc
                        print("\nShop location was successfully changed to "+ newLoc)

            if optL == "4":
                        shop4.shopLocation = newLoc
                        print("\nShop location was successfully changed to "+ newLoc)  

    #Call main menu function
    mainMenu()
    ans = input("Select an option or 99 to exit: ")
    #Use if to let user choose first option
    if ans == "99":
        break

    if ans == "1":
        managementMenu()
        opt = input("Select an option: ")

        #Let the user go back if 0 is choosen
        if opt == "0":
            managementMenu()

        if opt == "1":
            chngName()
            optN = input("Select an option: ")
            newName = input("Type the new Shop name: ")
        
            #Call function
            manageNameChng()

        if opt == "2":
            chngName()
            optL = input("Select an option: ")
            newLoc = input("Enter a location Free State, Gauteng, KZN, Limpopo: ")

            #Call function
            manageLocChng()

        if opt == "3":
            crrtShops()

        if opt == "4":
            allShopDetails()

    #Use if to let user choose second option
    if ans == "2":
        #Print all the items
        print("All items available\n")
        for key,value in stock.items():
            print(key,'--')
            for category, amount in value.items():
                print(category,':',str(amount))

        itm = input("\nSelect an item: ")

        itmNumber = int(input("Number of items bought: "))

        #Add or remove items 
        if itm == "1":
             stock['1. Computers']['In Stock'] -= itmNumber

        if itm == "2":
             stock['2. Cables']['In Stock'] -= itmNumber

        if itm == "3":
             stock['3. Components']['In Stock'] -= itmNumber

        if itm == "4":
             stock['4. Screens']['In Stock'] -= itmNumber

        print("\nSelect a shop to buy from")
        crrtShops()

        shopSlct = input("Select shop: ")

        #Add or remove customers and sales 
        if shopSlct == "1":
             shop1.customers += 1
             shop1.sales += 1

        if shopSlct == "2":
             shop2.customers += 1
             shop2.sales += 1

        if shopSlct == "3":
             shop3.customers += 1
             shop3.sales += 1

        if shopSlct == "4":
             shop4.customers += 1
             shop4.sales += 1

    #Use if to let user choose third option
    if ans == "3":
        print("Items allowed to be returned")
        for key,value in stock.items():
            print(key)

        #Create return option
        typeItemR = input("Items to be returned: ")

        amountItemR = input("Amount of items to be returned: ")

        crrtShops()         

        Rshop = input("Shop to be returned to: ")

        #Increase return and decrease sales
        if amountItemR:
            shop1.returns += 1
            shop1.sales -= 1
            
    #Use if to let user choose fourth option
    if ans == "4":
        print("1. Display stock")
        print("2. Add stock")
        print("0. Back")

        Sans = input("Please choose an option: ")

        if Sans == "1":
            for key,value in stock.items():
                print(key,'--')
                for category, amount in value.items():
                    print(category,':',str(amount))
        elif Sans == "2":
            print("Where do you want to add stock? ")
            for key,value in stock.items():
                print(key,'--')
                for category, amount in value.items():
                    print(category,':',str(amount))
            addStck = input("Please choice stock: ")
            ammAdd = int(input("Enter the amount to be added: "))

            #Add stock
            if addStck == "1":
                stock['1. Computers']['In Stock'] += ammAdd

            if addStck == "2":
                stock['2. Cables']['In Stock'] += ammAdd

            if addStck == "3":
                stock['3. Components']['In Stock'] += ammAdd

            if addStck == "4":
                stock['4. Screens']['In Stock'] += ammAdd

            elif Sans == "0":
                True