#Create ctuStock class with objects
class ctuStock:
    def __init__(self, shopName, shopLocation, customers, sales, returns):
        self.shopName = "Default"
        self.shopLocation = "Default"
        self.customers = 0
        self.sales = 0
        self.returns = 0